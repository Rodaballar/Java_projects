package com.example.tempomv;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.lang.reflect.AccessibleObject;


public class MainActivity extends AppCompatActivity {
        TextView textDisplayConverted;
        EditText editTemperature;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);


            textDisplayConverted =
                    (TextView) findViewById(R.id.textDisplayConverted);
            editTemperature = (EditText) findViewById(R.id.editTemperature);
        }
{
        }
        public void onButtonClicked(View view) {

            switch (view.getId()){
                case R.id.Fahrenheitknapp:
                    double celsius = Double.parseDouble(editTemperature.getText().toString());
                    double fahrenheit = celsius * 9.0/5.0 + 32.0;
                    textDisplayConverted.setText(Double.toString(fahrenheit));
                        break;
                case R.id.Celsiusknapp:
                    fahrenheit = Double.parseDouble(editTemperature.getText().toString());
                    celsius = (fahrenheit-32.0)*5.0/9.0;
                    textDisplayConverted.setText(Double.toString(celsius));
                        break;

            }

        }
    }
